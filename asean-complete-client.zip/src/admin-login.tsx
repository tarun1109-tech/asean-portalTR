export default function AdminLogin() {
  return <h2>Admin Login Page</h2>;
}