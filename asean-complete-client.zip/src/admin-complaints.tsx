export default function AdminComplaints() {
  return <h2>Admin Complaints View</h2>;
}