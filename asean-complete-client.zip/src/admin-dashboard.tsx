export default function AdminDashboard() {
  return <h2>Admin Dashboard</h2>;
}