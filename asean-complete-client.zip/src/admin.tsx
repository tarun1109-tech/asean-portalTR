export default function Admin() {
  return <h2>Admin Base Page</h2>;
}