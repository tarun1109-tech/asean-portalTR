export default function ComplaintForm() {
  return <h2>Complaint Form Page</h2>;
}