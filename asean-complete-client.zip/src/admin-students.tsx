export default function AdminStudents() {
  return <h2>Admin Students View</h2>;
}