export default function StudentLookup() {
  return <h2>Student Lookup Page (Marks Coming Soon)</h2>;
}