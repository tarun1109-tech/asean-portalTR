export function useToast(message: string) {
  alert(message);
}