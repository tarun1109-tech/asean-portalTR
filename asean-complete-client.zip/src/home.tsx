export default function Home() {
  return <h1>Welcome to the ASEAN School Portal</h1>;
}